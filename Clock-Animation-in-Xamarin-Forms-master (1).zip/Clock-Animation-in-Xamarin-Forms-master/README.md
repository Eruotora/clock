# Clock Animation in Xamarin Forms | Clock and Alarm App
In this Xamarin Forms Tutorial we will be looking at creating Clock Animation in Xamarin Forms. We will be making use of the SkiaSharp 2D Drawing engine to create a beautiful clock and alarm design.

You can watch the video here ➤ https://youtu.be/JbpDyRfaOqM

![alt text](https://devcrux.com/wp-content/uploads/Clock.gif)
